import logging
import argparse
import tink
import os
from encryption_wrapper import encryption
from encryption_wrapper.stream_encryption import StreamEncryptWithTink

from tink import streaming_aead


_TMP_LOCATION = os.getenv('GSUTIL_TMP_LOCATION',
                          os.path.expanduser('~') + '/.gsutil-wrapper/')
BLOCK_SIZE = 1024 * 1024  # The CLI tool will read/write at most 1 MB at once.

def test_stream_decrypt():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_filepath",
                        required=True,
                        help="Absolute path to encrypted file")
    parser.add_argument("--output_filepath",
                        required=True,
                        help="Absolute path to decrypted file")
    parser.add_argument("--kek_uri",
                        required=True,
                        help="Kek uri in gcp-kms:// format")
    parser.add_argument("--sa_path",
                        required=True,
                        help="Path to service account json file")
    args = parser.parse_args()

    # the linter is worried these variables might not be initialized, but we
    # won't ever get this far if --client_side_encryption isn't specified
    # noinspection PyUnboundLocalVariable

    try:
        tin = encryption.EncryptWithTink(args.kek_uri, args.sa_path, _TMP_LOCATION)
        
    except tink.TinkError as e:
        logging.exception('Error initialising Tink: %s', e)
        return
    print(">>>>>>>>>>> Param ", args)
    print(">>>>>>>>>>> test_stream_decrypt: input stream encrypt: ", args.input_filepath)
    print(">>>>>>>>>>> test_stream_decrypt: output stream encrypt: ", args.output_filepath)

    with open(file=args.output_filepath, mode="wb") as output_file:
        with open(file=args.input_filepath, mode="rb") as input_file:
            StreamEncryptWithTink.stream_decrypt_file(input_file, output_file, tin.associated_data, 
                                                  tin.streaming_aead_primitive, BLOCK_SIZE)

test_stream_decrypt()

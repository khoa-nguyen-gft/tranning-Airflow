import logging
import argparse
import tink
from tink import aead
from tink.core import TinkError
from tink.integration import gcpkms

def test_decrypt():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_filepath",
                        required=True,
                        help="Absolute path to encrypted file")
    parser.add_argument("--output_filepath",
                        required=True,
                        help="Absolute path to decrypted file")
    parser.add_argument("--kek_uri",
                        required=True,
                        help="Kek uri in gcp-kms:// format")
    parser.add_argument("--sa_path",
                        required=True,
                        help="Path to service account json file")
    args = parser.parse_args()

    try:
        aead.register()
    except tink.TinkError as e:
        logging.exception('Error initialising Tink: %s', e)
        return

    # Create envelope AEAD primitive using AES256 GCM for encrypting the data
    try:
        key_template = aead.aead_key_templates.AES256_EAX
        # '/home/jjni/workspace/dataflow/sa.json')
        gcp_client = gcpkms.GcpKmsClient(args.kek_uri, args.sa_path)
        gcp_aead = gcp_client.get_aead(args.kek_uri)
        env_aead = aead.KmsEnvelopeAead(key_template, gcp_aead)
    except tink.TinkError as e:
        logging.exception('Error creating primitive: %s', e)
        return

    with open(file=args.output_filepath, mode="wb") as output_file:
        with open(file=args.input_filepath, mode="rb") as input_file:
            binary_file = input_file.read()
            decrypted = env_aead.decrypt(binary_file, b'')
            output_file.write(decrypted)

test_decrypt()

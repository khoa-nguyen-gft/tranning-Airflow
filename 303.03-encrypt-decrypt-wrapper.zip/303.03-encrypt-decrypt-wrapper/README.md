
# 1. Active Enviroment
```bash
# Create virtual Python environment
python3.8 -m venv .venv

# Activate virtual Python environment
. .venv/bin/activate


# Install Python requirements
#   Ignore expected warning: 'WARNING: You are using pip version 19.3.1; however, version 22.2.2 is available.'
python3.8 -m pip install -r requirements.txt

```

# 2. Encrypt the file and Upload into Cloud.

Example:
```bash
source ~/.bashrc
export SERVICE_ACCOUNT_KEY_PATH=$GOOGLE_APPLICATION_CREDENTIALS
export PROJECT_ID="devops-simple"
export BUCKET_NAME="108-demo-gsutil"
export REGION="global"
export KEYRING_NAME=keyring-devops-simple
export LOCATION=global
export KEY_NAME=key-devops-simple
export FILE_NAME=mcifreference.dat.gz
export TEST_UPLOAD_FILE_NAME_1="data/$FILE_NAME"
export BUCKET_FILE_NNAME="stream-$FILE_NAME"
export TEST_DOWNLOAD_FILE_NAME_1_ENCRYPTED="data/download_stream-$FILE_NAME"
# upload encrypted file (using wrapped gsutil)
./gsutil cp --client_side_encryption=gcp-kms://projects/${PROJECT_ID}/locations/${REGION}/keyRings/${KEYRING_NAME}/cryptoKeys/${KEY_NAME},${SERVICE_ACCOUNT_KEY_PATH} "${TEST_UPLOAD_FILE_NAME_1}" gs://${BUCKET_NAME}/${BUCKET_FILE_NNAME}

```


# 3. Download file from bucket to local

Example:
```bash
source ~/.bashrc
export SERVICE_ACCOUNT_KEY_PATH=$GOOGLE_APPLICATION_CREDENTIALS
export PROJECT_ID="devops-simple"
export BUCKET_NAME="108-demo-gsutil"
export REGION="global"
export KEYRING_NAME=keyring-devops-simple
export LOCATION=global
export KEY_NAME=key-devops-simple
export FILE_NAME=mcifreference.dat.gz
export TEST_DOWNLOAD_FILE_NAME_1="data/download_stream_$FILE_NAME"
export BUCKET_FILE_NNAME="stream-$FILE_NAME"
export TEST_DOWNLOAD_FILE_NAME_1_ENCRYPTED="data/download_stream-$FILE_NAME"
# upload encrypted file (using wrapped gsutil)
./gsutil cp --client_side_encryption=gcp-kms://projects/${PROJECT_ID}/locations/${REGION}/keyRings/${KEYRING_NAME}/cryptoKeys/${KEY_NAME},${SERVICE_ACCOUNT_KEY_PATH} gs://${BUCKET_NAME}/${BUCKET_FILE_NNAME} "${TEST_UPLOAD_FILE_NAME_1}"


```


# 4. Run testing script which decrypts data

```bash
#/Users/kany/gsutil/gsutil -o "GSUtil:parallel_composite_upload_threshold=150M" cp /Users/kany/.gsutil-wrapper/KPhFGIcY/stream_department-data.txt gs://108-demo-gsutil/stream-department-data.txt


source ~/.bashrc
export SERVICE_ACCOUNT_KEY_PATH=$GOOGLE_APPLICATION_CREDENTIALS
export PROJECT_ID="devops-simple"
export KEYRING_NAME=keyring-devops-simple
export KEY_NAME=key-devops-simple
export REGION="global"
export FILE_NAME=mcifreference.dat.gz
export TEST_DOWNLOAD_FILE_NAME_1_ENCRYPTED="data/download_stream-$FILE_NAME"
export PYTHONPATH="${PYTHONPATH}:/Users/kany/project-local/data-home/tranning-Airflow/303.03-encription-descript-wrapper"
export INPUT_FILEPATH="/Users/kany/.gsutil-wrapper/T73PK6Cz/stream_mcifreference.dat.gz "


#run testing script which decrypts data
python3.8 testing/test_stream_decrypt.py \
--kek_uri=gcp-kms://projects/${PROJECT_ID}/locations/${REGION}/keyRings/${KEYRING_NAME}/cryptoKeys/${KEY_NAME} \
--sa_path=${SERVICE_ACCOUNT_KEY_PATH} \
--input_filepath=${INPUT_FILEPATH} \
--output_filepath=${TEST_DOWNLOAD_FILE_NAME_1_ENCRYPTED}
```

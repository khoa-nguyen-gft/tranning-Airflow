#!/usr/bin/env python3

from tink import JsonKeysetWriter
from tink.integration import gcpkms
from tink.core import TinkError
from tink import aead
import tink
import os
import logging

logging.basicConfig(level='INFO')

class KeysetHandler(object):
    """Perform local encryption and decryption with Tink."""

    def __init__(self, key_uri, creds, streaming_aead_key_templates):

        # Initialize Tink
        aead.register()

        # Generate the KEK
        # Read the GCP credentials and setup client
        gcpkms.GcpKmsClient.register_client(key_uri, creds)

        # Create an AEAD primitive from the key-encryption key (KEK) for encrypting
        # Tink keysets
        handle = tink.new_keyset_handle(aead.aead_key_templates.create_kms_aead_key_template(key_uri))
        self.kek_gcp_aead = handle.primitive(aead.Aead)

        # Generate the DEK
        self.dek_keyset_handle = tink.new_keyset_handle(streaming_aead_key_templates)


    # Encrypt the keyset_handle with the remote key-encryption key (KEK)
    def create_keyset_file(self, keyset_file_path):
        # Encrypt the keyset_handle with the remote key-encryption key (KEK)
        with open(keyset_file_path, 'wt') as keyset_file:
            self.dek_keyset_handle.write(tink.JsonKeysetWriter(keyset_file), self.kek_gcp_aead)


    # Read the encrypted keyset into a keyset_handle
    def load_keyset_file(self, keyset_file_path):
        # Encrypt the keyset_handle with the remote key-encryption key (KEK)
        with open(keyset_file_path, 'rb') as keyset_file:
            text = keyset_file.read()
            return  tink.KeysetHandle.read(tink.JsonKeysetReader(text), self.kek_gcp_aead)


    #check the key set file is exists
    def check_keyset_file_exists(self, keyset_file_path): 
        dictionary = os.path.dirname(keyset_file_path)
        if not os.path.exists(dictionary):
            os.makedirs(dictionary)

        if os.path.exists(keyset_file_path):
            with open(keyset_file_path, "rb") as keyset_file_content: 
                file_content = keyset_file_content.read()
                if len(file_content) > 0:
                    return True
        else:
            return False

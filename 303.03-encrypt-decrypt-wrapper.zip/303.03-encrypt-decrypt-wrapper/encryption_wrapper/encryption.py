#!/usr/bin/env python3

from tink import JsonKeysetWriter
from typing import BinaryIO
from tink import tink_config
from tink import streaming_aead
from tink.integration import gcpkms
from tink.core import TinkError
from tink import aead
import tink
from encryption_wrapper.common import error_and_exit
from .keyset_handler import KeysetHandler
from .stream_encryption import StreamEncryptWithTink
import os
import shutil
import stat
import logging

logging.basicConfig(level='INFO')

_TMP_LOCATION = os.getenv('GSUTIL_TMP_LOCATION',
                          os.path.expanduser('~') + '/.gsutil-wrapper/')
BLOCK_SIZE = 1024 * 1024  # The CLI tool will read/write at most 1 MB at once.
associated_data = b'PASSWORD' 
KEYSET_FILE_PATH = "keyset/20230620_11h_encrypt-keyset.bin"

class EncryptWithTink(object):
    """Perform local encryption and decryption with Tink."""

    def __init__(self, key_uri, creds, tmp_location=_TMP_LOCATION):

        self.tmp_location = tmp_location
        # Make the tmp dir if it doesn't exist
        if not os.path.isdir(self.tmp_location):
            # noinspection PyUnusedLocal
            try:
                os.makedirs(self.tmp_location)
            except FileExistsError:
                # This is ok because the directory already exists
                pass
            except OSError as os_error:
                error_and_exit(str(os_error))

        # Initialize Tink
        try:
            print("Start init tink enviroment")
            aead.register()
            tink_config.register()
            streaming_aead.register()

            # print(">>>>>>key_uri:", key_uri)
            # print(">>>>>>creds:", creds)

            self.key_template = aead.aead_key_templates.AES256_EAX
            self.keyset_handle = tink.new_keyset_handle(self.key_template)

            gcp_client = gcpkms.GcpKmsClient(key_uri, creds)
            gcp_aead = gcp_client.get_aead(key_uri)
            self.env_aead = aead.KmsEnvelopeAead(self.key_template, gcp_aead)

            # Get the stream aead primitive.
            try:
                self.keyset_file_path = KEYSET_FILE_PATH
                self.stream_keyset_handle = KeysetHandler(key_uri, creds, streaming_aead.streaming_aead_key_templates.AES256_CTR_HMAC_SHA256_1MB)
                self.streaming_aead_primitive = self.generate_gcp_keyset_handle()
                self.associated_data = associated_data

            except tink.TinkError as e:
                error_and_exit('Error creating streaming AEAD primitive from keyset: %s',e)


        except TinkError as tink_init_error:
            error_and_exit('tink initialization failed: ' +
                           str(tink_init_error))


    def encrypt(self, filepath):
        if os.path.isdir(filepath):
            error_and_exit('cannot encrypt a directory')
        elif stat.S_ISFIFO(os.stat(filepath).st_mode):
            error_and_exit('cannot encrypt a FIFO')

        filename = os.path.basename(filepath)
        encrypted_filepath = self.tmp_location + '/' + filename
        try:
            shutil.copyfile(filepath, encrypted_filepath)
        except OSError as copy_error:
            error_and_exit("EXCEPTION COPY", str(copy_error))

        try:
            with open(filepath, 'rb') as f:
                plaintext = f.read()
            ciphertext = self.env_aead.encrypt(plaintext, b'')
            with open(encrypted_filepath, 'wb') as f:
                f.write(ciphertext)
        except TinkError as encryption_error:
            error_and_exit("encryption_error", str(encryption_error))
        return encrypted_filepath


    def decrypt(self, filepath):
        filename = os.path.basename(filepath)
        decrypted_filepath = self.tmp_location + '/' + filename

        try:
            with open(filepath, 'rb') as f:
                ciphertext = f.read()
            cleartext = self.env_aead.decrypt(ciphertext, b'')
            with open(decrypted_filepath, 'wb') as f:
                f.write(cleartext)
            shutil.copyfile(decrypted_filepath, filepath)
            os.unlink(decrypted_filepath)
        except TinkError as decryption_error:
            error_and_exit(str(decryption_error))

        return decrypted_filepath

    
    def stream_encrypt(self, filepath):
        print(">>>>>>>>>>> EncryptWithTink: stream encrypt: ", filepath)
        if os.path.isdir(filepath):
            error_and_exit('cannot encrypt a directory')
        elif stat.S_ISFIFO(os.stat(filepath).st_mode):
            error_and_exit('cannot encrypt a FIFO')

        filename = os.path.basename(filepath)
        encrypted_filepath = self.tmp_location + '/' +  'stream_' + filename
        try:
            shutil.copyfile(filepath, encrypted_filepath)
        except OSError as copy_error:
            error_and_exit("EXCEPTION COPY", str(copy_error))

        # print(">>>>>>>>>>> EncryptWithTink: input stream encrypt: ", filepath)
        # print(">>>>>>>>>>> EncryptWithTink: output stream encrypt: ", encrypted_filepath)

        try:
            with open(filepath, 'rb') as input_file:
                with open(encrypted_filepath, 'wb') as output_file:
                    StreamEncryptWithTink.stream_encrypt_file(input_file, output_file, associated_data, self.streaming_aead_primitive, BLOCK_SIZE)

        except TinkError as encryption_error:
            error_and_exit("encryption_error", str(encryption_error))
        return encrypted_filepath


    def stream_decrypt(self, filepath):
        filename = os.path.basename(filepath)
        decrypted_filepath = self.tmp_location + '/' + filename

        # print(">>>>>>>>>>> filepath: input stream encrypt: ", filepath)
        # print(">>>>>>>>>>> decrypted_filepath: output stream encrypt: ", decrypted_filepath)

        try:
            with open(filepath, 'rb') as input_file:
                with open(decrypted_filepath, 'wb') as output_file:
                    StreamEncryptWithTink.stream_decrypt_file(input_file, output_file, associated_data, self.streaming_aead_primitive, BLOCK_SIZE)

            shutil.copyfile(decrypted_filepath, filepath)
            os.unlink(decrypted_filepath)
        except TinkError as decryption_error:
            error_and_exit(str(decryption_error))

        return decrypted_filepath

    def generate_gcp_keyset_handle(self):
        # print(">>>>>>>>>start generate_gcp_keyset_handle", self.keyset_file_path)
        if not self.stream_keyset_handle.check_keyset_file_exists(self.keyset_file_path):
            self.stream_keyset_handle.create_keyset_file(self.keyset_file_path)
        
        keyset_handle = self.stream_keyset_handle.load_keyset_file(self.keyset_file_path)
        return keyset_handle.primitive(streaming_aead.StreamingAead)
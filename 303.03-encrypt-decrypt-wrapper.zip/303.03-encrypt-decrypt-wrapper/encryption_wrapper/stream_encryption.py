#!/usr/bin/env python3

from typing import BinaryIO

from tink import JsonKeysetWriter
from tink import streaming_aead
from tink.core import TinkError
import logging

logging.basicConfig(level='INFO')

class StreamEncryptWithTink(object):

    @staticmethod
    def stream_encrypt_file(input_file: BinaryIO, output_file: BinaryIO,
                 associated_data: bytes,
                 primitive: streaming_aead.StreamingAead,
                 block_size):
        """Encrypts a file with the given streaming AEAD primitive.

        Args:
            input_file: File to read from.
            output_file: File to write to.
            associated_data: Associated data provided for the AEAD.
            primitive: The streaming AEAD primitive used for encryption.
        """
        with primitive.new_encrypting_stream(output_file, associated_data) as enc_stream:
            for data_block in StreamEncryptWithTink.read_as_blocks(input_file, block_size):
                enc_stream.write(data_block)


    @staticmethod
    def stream_decrypt_file(input_file: BinaryIO, output_file: BinaryIO,
                 associated_data: bytes,
                 primitive: streaming_aead.StreamingAead, 
                 block_size):
        """Decrypts a file with the given streaming AEAD primitive.

            This function will cause the program to exit with 1 if the decryption fails.

            Args:
                input_file: File to read from.
                output_file: File to write to.
                associated_data: Associated data provided for the AEAD.
                primitive: The streaming AEAD primitive used for decryption.
        """
        with primitive.new_decrypting_stream(input_file, associated_data) as dec_stream:
            for data_block in StreamEncryptWithTink.read_as_blocks(dec_stream, block_size):
                output_file.write(data_block)


    @staticmethod
    def read_as_blocks(file: BinaryIO, block_size):
        """Generator function to read from a file BLOCK_SIZE bytes.
        Args:
            file: The file object to read from.
        Yields:
            Returns up to block_size bytes from the file.
        """
        while True:
            data = file.read(block_size)
            # If file was opened in rawIO, EOF is only reached when b'' is returned.
            # pylint: disable=g-explicit-bool-comparison
            if data == b'':
                break
            # pylint: enable=g-explicit-bool-comparison
            yield data